<template>
	<h1>recharge</h1>
</template>

<script lang="ts" setup>
	
</script>
<style>
	
</style>
